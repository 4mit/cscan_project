 <!DOCTYPE html>
<html>

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 8px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
.button4 {border-radius: 12px;}
</style>
<body>
<h2 align="center">WELCOME TO ADMIN PANEL</h2>
<a href="../root/demo.php"><button class="button button4">Logout</button></a><br/>
<table width="1275" height="73" border="5" align="center" bgcolor="#f2e4e3">
<tr>
	<td colspan="20" align="center" bgcolor="#600415"><h2 style="color:white">Students Details</h2></td>
</tr>
<tr align="center" bgcolor="pink">
	<td align="center"><b>Serial No.</b></td>
	<td align="center"><b>Student Name</b></td>
    <td align="center"><b>email Id</b></td>
    <td align="center"><b>Contact</b></td>
    <td align="center"><b>Semester</b></td>
    <td align="center"><b>Program</b></td>
    <td align="center"><b>Institute</b></td>
    <td align="center"><b>Accompaying Faculty</b></td>
    <td align="center"><b>Food Preference</b></td>
</tr>

<?php
$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca") or die('connection failed');
$que = "select *from student";
$run = mysqli_query($con,$que);
while($row = mysqli_fetch_array($run))
{
	$a = $row[0];
	$b = $row[1];
	$c = $row[2];
	$d = $row[3];
	$e = $row[4];
	$f = $row[5];
	$g = $row[6];
	$h = $row[7];
	$i = $row[8];
?>
		<tr>
			<td align="center"><?php echo $a;?></td>
			<td align="center"><?php echo $b;?></td>
			<td align="center"><?php echo $c;?></td>
			<td align="center"><?php echo $d;?></td>
			<td align="center"><?php echo $e;?></td>
			<td align="center"><?php echo $f;?></td>
			<td align="center"><?php echo $g;?></td>
			<td align="center"><?php echo $h;?></td>
			<td align="center"><?php echo $i;?></td>
		</tr>
<?php } ?>
</table></br>

<table width="1275" height="73" border="5" align="center" bgcolor="#f2e4e3">
<tr>
	<td colspan="20" align="center" bgcolor="#600415"><h2 style="color:white">Faculty Details</h2></td>
</tr>
<tr align="center" bgcolor="pink">
	<td align="center"><b>Serial No.</b></td>
	<td align="center"><b>Faculty Name</b></td>
    <td align="center"><b>Institute</b></td>
    <td align="center"><b>Gender</b></td>
    <td align="center"><b>Designation</b></td>
    <td align="center"><b>Phone</b></td>
    <td align="center"><b>Email</b></td>
    <td align="center"><b>Area Of Intrest</b></td>
    <td align="center"><b>Food Preference</b></td>
    <td align="center"><b>Program</b></td>
</tr>

<?php
$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca") or die('connection failed');
$que = "select *from faculty";
$run = mysqli_query($con,$que);
while($row = mysqli_fetch_array($run))
{
	$a = $row[0];
	$b = $row[1];
	$c = $row[2];
	$d = $row[3];
	$e = $row[4];
	$f = $row[5];
	$g = $row[6];
	$h = $row[7];
	$i = $row[8];
	$j = $row[8];
?>
		<tr>
			<td align="center"><?php echo $a;?></td>
			<td align="center"><?php echo $b;?></td>
			<td align="center"><?php echo $c;?></td>
			<td align="center"><?php echo $d;?></td>
			<td align="center"><?php echo $e;?></td>
			<td align="center"><?php echo $f;?></td>
			<td align="center"><?php echo $g;?></td>
			<td align="center"><?php echo $h;?></td>
			<td align="center"><?php echo $i;?></td>
			<td align="center"><?php echo $j;?></td>
		</tr>
<?php } ?>
</table>
</body>
</html>
