<html>
<head>
<script src="root/bt/js/bootstrap.js"></script>
<link href="root/bt/css/bootstrap.css" rel="stylesheet" >

</head>
	<body >
    <div class="container">
    <div class="row"> 
  			<h1 align="center">Faculty  Registration </h1>
                        <form action="faculty.php" method="post" class="form-inline">
                        
                        <table width="200" border="1" class="table">
                  <tbody>
                    <tr>
                      <td>Name</td>
                      <td><input type="text" name="name" placeholder="Enter The Name" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>INSTITUTE</td>
                      <td><select name="ins" placeholder="Select College" class="form-control"><br/><br/>
                                    <option>National Institute Of Techonology Warangal</option>
                                    <option>National Institute Of Techonology Calicut</option>
                                    <option>National Institute Of Techonology Trichy</option>
                                    <option>National Institute Of Techonology Surathklal</option>
                                    <option>National Institute Of Techonology Krukshetra</option>
                                    <option>National Institute Of Techonology Bhopal</option>
                                    <option>National Institute Of Techonology Jameshedpur</option>
                                    <option>National Institute Of Techonology Rourkela</option>
                                    <option>National Institute Of Techonology Goa</option>
                                    <option>National Institute Of Techonology Hamirpur</option>
                                    <option>National Institute Of Techonology Jaipur</option>
                                    <option>National Institute Of Techonology Mizrom</option>
                                    <option>National Institute Of Techonology Patna</option>
                                    <option>National Institute Of Techonology Warangal</option>
                                    <option>National Institute Of Techonology Nagaland</option><br/>
                                    <option  id="others_institute">Other</option><br/>
                                    </select>
                                    Other<input type="text" id="others_institute" class="form-control">
                                    </td>
                    </tr>
                    <tr>
                      <td>SEX</td>
                      <td><input type="radio" name="gender" value="Male" pattern="Male" class="form-control">Male
                      
                      <input type="radio" name="gender" value="Female" pattern="Female" id="check_gender" class="form-control">Female
                      </td>
                    </tr>
                    <tr>
                      <td>DESIGNATION</td>
                      <td><select name="des" placeholder="Enter The Designation" required class="form-control">
                                    <option>Professor</option>
                                    <option>Assitant Professor</option>
                                    <option>Associate Professor</option>
                                    <option>Others</option><br/><br/>
                            </select>
                            
                            Others:&nbsp;&nbsp;<input type="text" id="desig" name="designation" class="form-control">
                            </td>
                    </tr>
                    <tr>
                      <td>CONTACT</td>
                      <td><input id ="contact" type="text" name="phone" placeholder="Enter The Mobile Number" pattern="[0-9]{10}" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>EMAIL</td>
                      <td><input type="email" name="email" placeholder="Enter The Email" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>AREA</td>
                      <td><input type="text" name="area" placeholder="Enter The Area Of Interest" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>FOOD PREFERENCES</td>
                      <td><select name="food_pref" required class="form-control"><br/>
                                            <option>Vegetarian</option>
                                            <option>Non-Vegetarian</option>
                                            </select></td>
                    </tr>
                    <tr>
                      <td>PROGRAM</td>
                      <td><select name="program" class="form-control"
                                    <option>MCA</option>
                                    <option>Phd</option>
                                    <option>MTECH</option>				
                                    <option>Btech</option>
                                    <option id="others_program">Others</option><br/>
                                    </select>
                                    
                                    Others:&nbsp;&nbsp;&nbsp;<input type="text" id="others_program" pattern="[a-zA-Z]{5,20}" class="form-control">
                                    </td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td><button type="submit" name="faculty_egister" onclick="return check_val();" class="btn btn-danger">submit</button></td>
                    </tr>
                    
                  </tbody>
                </table>
                
                        
        <a href="root/demo.php">Back to home page </a>
        
        
        
       
     </div>
    </div> 
	<script>
	function check_val()
	{
		var a =document.getElementById('contact').value;            
		if(/[0-9]{10}/.test(a))
		  retrun true;
		else
		{	                     
                    alert("Invalid Phone Number ");
                    document.getElementById('contact').style.border = "2px solid red";
                    return false;                    
		}
	}
</script>	
	</body>
	</html>
				
				
<?php 

if(isset($_POST['faculty_egister']))
{
	
		$name=$_POST['name'];
$ins=$_POST['ins'];
$sex=$_POST['gender'];
$des=$_POST['des'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$area=$_POST['area'];
$food=$_POST['food_pref'];
$program=$_POST['program'];

echo $des;

$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca");
if($con){
	
if($sex =="Male" || $sex=="Female"){
		$sql="insert into faculty values('','$name','$ins','$sex','$des','$phone','$email','$area','$food','$program')";

	if($con->query($sql))
		echo '<script>alert("DATA INSERTED SUCCESSFULL")</script>';
	else
		echo '<script>alert(" NOT INSERTED SUCCESSFULL")</script>';
	
	}
else{
	echo "<script>alert('Select Gender')</script>";
	}		
	
}
else{echo "cant connect";}
	
	
	}



?>
