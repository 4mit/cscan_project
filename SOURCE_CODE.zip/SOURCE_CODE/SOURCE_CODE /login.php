<?php
if(isset($_POST['submit']))
{
	$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca");	
    $username=$_POST['user'];
    $password=$_POST['password'];
    $t =$_POST['type'];
	
    if($t=="Student")
    {
        
        $sql="SELECT * FROM student WHERE email='$username' and pass='$password'";
        
        $result=$con->query($sql);
        
        if($result->num_rows>0)
		{
													
                    //echo "OK FOUND ";
                    //session_destroy();    
                    session_start();
                    $serach_id= "select stu_id from student where email='$username'";
                    
                    $searched_id =$con->query($serach_id);
                    
                    while($et = $searched_id->fetch_assoc())
                    {
                        
                        $id = $et['stu_id'];
                        
                    }            
            
                    $_SESSION['user']= $username;
                    $_SESSION['id']= $id;
            
                    header("location:user/user.php");
                
		}else{
					
					echo "<script>alert('USERNAME AND PASSWORD NOT EXISTS')</script>";
										
		}
        
    }
    if($t=="Admin")
    {
        
        $sql="SELECT * FROM admin WHERE user='$username' and pass='$password'";
        
        $result=$con->query($sql);
        
        if($result->num_rows>0)
				{
							
						//echo "OK FOUND ";	
                    session_destroy();
                    session_start();
            
                    $_SESSION['user']= $username;
            
                    header("location:admin/admin.php");
            
				}else{
					
					echo "<script>alert('USERNAME AND PASSWORD NOT EXISTS')</script>";
										
			    }
        
    } 
    
    
}
?>

<!DOCTYPE html>

<head>
    <title>Login Form</title>
    <script src="root/bt/js/bootstrap.js"></script>
<link href="root/bt/css/bootstrap.css" rel="stylesheet" >
    <script src="root/jquery-1.9.1.js"></script>

    
    <style>

        body{background-color: black;
        color:aliceblue;}
.wrapper {
  padding: 1px 0;
}

.bs-example-tabs .nav-tabs {
  margin-bottom: 10px;
}

@media (max-width: 400px) {
  #narrow-browser-alert {
    display: none;
  }
}
</style>
</head>
<html>
    <div class="row">
        <div class="e" style="padding:50px;">
                <div class="wrapper">
      <center><h3 style="color:#1E90FF; font-size:50px"><b>Login</b></h3></center><br/>
    <form class="form-signin" action="login.php" method="POST">       
      <h5 class="form-signin-heading">  <br/><br/>
        <b>Username:&nbsp;</b><br/><br/><input type="text" name="user"  placeholder="Username " class="form-control" required autofocus="">
          <br/>

      <b>Password:<br/>&nbsp;</b><input type="password" name="password" placeholder="Password" class="form-control" required>     
      <br/>
          
      <div class="form-group">
          <p>Choose Login Type </p>
            <select name="type" class="form-control">
            <option class="form-control">
                    Student
                
            </option>  
            <option class="form-control">
                    Admin
            </option>
          
         </select>  
          </div>      
          
      <br/>      
      <center><button class="btn btn-primary btn-block" type="submit" name="submit">Login</button></center>   
    </form><br/>
        <a href="root/demo.php"><font size="5px" >Back to home</font></a>
        </div>  
</div>
</div>
</html>



  

