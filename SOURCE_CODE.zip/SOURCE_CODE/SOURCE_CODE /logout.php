<?php

session_start();

id(isset($_SESSION['user'])){
    
    session_destroy();
    header("location:../root/demo.php");
    
    
}
?>