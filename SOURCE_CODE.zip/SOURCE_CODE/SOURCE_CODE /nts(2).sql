-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 05, 2016 at 01:50 AM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nts`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user`, `pass`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `f_id` int(5) NOT NULL,
  `name` varchar(40) NOT NULL,
  `sex` char(1) NOT NULL,
  `design` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `int_area` varchar(60) NOT NULL,
  `food_pref` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE IF NOT EXISTS `organizer` (
  `org_id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `ename` varchar(100) NOT NULL,
  `day` date NOT NULL,
  `time` time NOT NULL,
  `speaker` text NOT NULL,
  `subject` varchar(50) NOT NULL,
  `concern` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`ename`, `day`, `time`, `speaker`, `subject`, `concern`) VALUES
('fghfghfghf', '2016-11-09', '06:23:26', 'fghfdjhstruj', 'tyhhgfhfg', 'Mtech'),
('rtyrtyrty', '2016-11-09', '04:27:59', 'jhkghhfghf', 'ggf', 'gfkjdg');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `stu_id` int(5) NOT NULL,
  `stu_name` char(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `sem` int(2) NOT NULL,
  `program` varchar(50) NOT NULL,
  `institute` text NOT NULL,
  `acm_faculty` varchar(11) NOT NULL,
  `food_pref` varchar(11) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stu_id`, `stu_name`, `email`, `phone`, `sem`, `program`, `institute`, `acm_faculty`, `food_pref`, `pass`) VALUES
(103, 'Student3', 'amitasdfbasjhg@ffhsd.com', '364783648', 4, 'gfkjdg', 'kjhddfkjdjkfbdkjgfdh', 'fghf', 'hfgh', '4356465'),
(100, 'nitesh', 'nitesh@gmail.com', '1234567890', 5, 'MCA', 'NATIONAL INSTITUTE OF TECHNOLOGY ', 'Faculty1 ', 'Veg', 'pass'),
(101, 'Strudent 1', 'email1@gmail.com', '123456789', 3, 'Mtech', 'National Institute of technology Trichy', 'Faculty2', 'Veg', '45454545');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`user`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
 ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
 ADD PRIMARY KEY (`ename`), ADD KEY `subject` (`subject`), ADD KEY `concern` (`concern`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
 ADD PRIMARY KEY (`program`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
ADD CONSTRAINT `student_schdule` FOREIGN KEY (`concern`) REFERENCES `student` (`program`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
