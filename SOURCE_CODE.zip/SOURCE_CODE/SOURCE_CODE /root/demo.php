<?php
$conn= new mysqli("localhost","m140366ca","m140366ca","db_m140366ca");
if(isset($_POST['reg_s']))
{
		if($conn)
		{
				$a = $_POST['name'];
				$b = $_POST['email'];
				$c= $_POST['phone'];
				$d= $_POST['c_sem'];
				$e = $_POST['programe'];
				$f =$_POST['institute']; 
				$g = $_POST['ac_fac'];
				$h = $_POST['f_pref'];
				
				$seacrhrUser  = "SELECT phone FROM `student` WHERE phone=1234567890";
				
				$seacrhrUserResult =$conn->query($seacrhrUser);
				
				if($seacrhrUserResult){
					
					if($seacrhrUserResult->num_rows >0){
							
						echo '<script>window.alert("Cant Register You User Alredy Exists");</script>';
						
							
					}else{
						
						echo '<script>window.alert("Noe You Can Register ");</script>';	
					}
				}else{echo '<script>window.alert("Cant Run Query  ");</script>';	}	
		
		}else{
				
					echo '<script>window.alert("Cant Connect To Server ");</script>';
				
		}

}	


?>
<html>
<head>


<script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
	
	
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" href="bt/css/bootstrap.css">
  <script src="jquery-1.9.1.js"></script>
  <script src="bt/js/bootstrap.js"></script>	
	<script type="text/javascript" src="jquery-1.9.1.js"></script>
  <script type="text/javascript" src="jquery.onepage-scroll.js"></script>
  <link href="onepage-scroll.css" rel='stylesheet' type='text/css'>
  <meta name="viewport" content="initial-scale=1, width=device-width, maximum-scale=1, minimum-scale=1, user-scalable=no">
  
  <link rel="stylesheet" href="css/style.css">
  <script>
$(document).ready(function(){
  $("a").on('click', function(event) {   
    if (this.hash !== "") { 
      event.preventDefault();  
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){    
        window.location.hash = hash;
      });
    } 
  });
});

</script>

	<script>
	  $(document).ready(function(){
      $(".main").onepage_scroll({
        sectionContainer: "section",
        responsiveFallback: 600,
        loop: true
      });
		});
		
	</script>
</head>
<body>
	
    <!-- -->
    <br/>
    <br/>       
        <nav class="navbar navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
              
                    <a class="navbar-brand" href=""><b>NITC<b></a> <img src="assets/nitc.png" height="42" width="42"> 
                </div>
                <div id="navbar" class="navbar-collapse collapse" >
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="demo.php" class="" style="color:orange">Home</a></li>
                        <li class=" dropdown"><a href="" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="color:orange">Events  <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="../schedule.html" style="color:orange">Schedule </a></li>
                                <li><a href="#event" style="color:orange">Speaker </a></li>
                                <li><a href="../submission.php" style="color:orange">Paper Submission </a></li>
                            </ul>
                        </li>
                        <li><a href="#acco" style="color:orange">Accomodation</a></li>
                        			
                        <li><a href="#commity" style="color:orange">Committee</a></li>
                        <li ><a href="../login.php"><font color="orange">Login</font></a></li>
                        <li><a href="#spo"><font color="orange">Sponsors</font></a></li>  
                        <li ><a href="#FAQ"><font color="orange">FAQ</font></a></li>
                        <li><a href="#reg"><font color="orange">Register</font></a></li>
                        <li><a href="#cfl" style="color:orange">Call For Papers</a></li>
                        <li><a href="#about_us" style="color:orange">About Us</a></li>		                        
                    </ul>
                    <body onload="startTime()">
					<div id="txt" style="padding-left:70em; padding-top:1.2em;"></div>
					</body>
                </div>
            </div>
            
        </nav>
        
    
    <!--  -->

  <div class="wrapper">
	  <div class="main">
		<section class="page1" style=" background-image:url(assets/main.jpg);" id="about">
			<div class="page_container">
				<div  class="section" id="second">
					<!--center><b><h1 style="color:blue; padding-down:0em">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Conference Portal </h1></b></center-->
                    <p style="color:black; font-size:37px;"><b><div class="background">
				  
  <div class="transbox">
    
  </div>
</div><!--p><font color="white"; size="4.5px">Conference Management Portal 2017, the first of its kind, is a conference aimed at bringing in student-teacher fraternity of CSE Departments of reputed IITSs,NITs etc across the nation under a single umbrella for exchange of ideas to spark innovation. The conference would serve as a platform to improve interaction and bridge the gap between faculty and students of different NITs. This would help identify patrons of similar research areas and help initiate collaboration in research projects to subsequently publish research papers. This conference presents an excellent opportunity for students among various NITs to collaborate and form strong ties of technical expertise. This year's edition of Conference Portal 2017 will be hosted by National Institute of Technology Calicut.</b></p-->			
	</font>	</p>
	</div>    
          </div>  	    
      </section>
	    <!-- -->
	    
	   
	    <!-- -->
	    
	    
	    <section class="page3" id="five" style="background-color:black; font-size:20px;">
	      <div class="container" id="acco">
				<div class="col col-sm-6" style="margin-top:-80px;">
					<br/>
					<br/>
					<br/>
					<br/>
					<br/>
					<br/>
					<h2 align="center" style="color:#EC830E; font-size:40px;"><b>Accomodation</b></h2>
					<p align="left"  style="font-size:15px;" >
						Arrangements will be made for the free accommodation and food for the students from the participating NITs at the NIT Calicut hostels. Sufficient assistance will be provided for the faculty members for their stay in hotels near NIT Calicut campus. Around 15 rooms are reserved for the faculty participants in NITC guest house which can be booked in advance on FCFS. The conference is co-sponsored by TEQIP-II at NIT Calicut. It is expected that the faculty participants would avail the funding from TEQIP in their respective institutions or any other sources like PDA to meet the expenses towards their travel and accommodation. Local hospitality including pickup and drop will be taken care by the organizing team. 
					</p>
                    <a href="#"><button class="btn btn-info accom">Details</button></a>
				</div>
				<div class="col col-sm-6" style="margin-top:-80px;">
					<br/>
					<br/>
					<br/>
					<br/>
					<br/>
					<br/>
					<h2 align="center" style="color:#EC830E;font-size:40px;"><b>Travel</b></h2>
					<p align="left"  style="font-size:15px;">
						NITC is well connected by railway, air and road facilities. The Calicut Railway station(CLT) is well connnected to all major stations in India. The Kozhikode International Airport(CCJ) provides daily flights to and from major cities in India. Once you reach the Railway Station or the Airport, take a cab or bus (towards Mukkam or REC/NIT) to NITC by asking for REC or NIT Calicut. Buses leave every 10-15 minutes from the main bus stand, Palayam Bus stand to REC. 
					</p><br/><br/><br/><br/>
                    <a href="#"><button class="btn btn-info accom">Details</button></a>
				</div>
  	       </div>
      </section>
      
      
      
      
      
      <!-- -->
      
      
	    <section class="page4" id="four" >
	      <div class="registration" id="reg">
			  <div class="container-fluid">
				<div class="row" style="margin-top:-60px; color:white;" >
				  <h1 class="center" style="color:orange;"><font size="7" >Registration</h1>
				  <div class="col-md-5 col-md-offset-1" style="padding-top:-25px;">
					<h3 class="impdate" style="font-size:25px;color:orange;"><b>Important Dates</b></h3>
					<ul class="datemenu">
					  <li style="font-size:20px;  color:white">
                      <span class="glyphicon glyphicon-calendar"></span>Registration opens : 12<sup>th</sup> JAN 2017</li>
							  <li style="font-size:18px;  color:white">
								<span class="glyphicon glyphicon-calendar"></span> Last date for Registration : 30<sup>th</sup> JAN 2017</li>
							  <li style="font-size:18px;  color:white">
								<span class="glyphicon glyphicon-calendar"></span> Confirmation :5<sup>th</sup> FEB 2017</li>
							</ul>
						  </div>
						  <div class="col-md-4 col-md-offset-1"  style="padding-top:-20px;">
							<h3 class="center" style="font-size:25px;  color:orange"><b>Eligibility</b></h3>
							<p class="justify" style="font-size:15px;  color:white">Conference is open to individuals who by education or experience give evidence of competence in an designated field. The designated fields are: Engineering, Computer Sciences and Information Technology, Physical Sciences, Biological and Medical Sciences, Mathematics, Technical Communications, Education, Management, and Law and Policy.</p>
						  </div>

						</div>

						<div class="btncont">
						  <a class="btn btn-lg btn-danger" href="../student.php" id="register">Student </a>
						  <a class="btn btm-lg btn-danger" href="../faculty.php" id="register">Faculty </a>
						</div>
					  </div>
					</div>
      </section>
      
      
      <!-- -->
      <!--
       <section class="page2" id="commity">
	      <div class="e_container">
            COmmity Goes Here 
			
	      </div>
      </section>
      
      
      
	    
      -->
      <!-- -->
      
	    <section class="page6" id="event">
	      <div class="page_cner">
            <div class="row" style="margin-left:0px;padding-left:-20px;">
                <br/>
                <div class="col col-sm-12">
                    <table class="table" width="600px" >
                        <tr>
                        	<td align="center" colspan="10"> <b><font size="8" color="#ED7D0E">Speakers</font></b></td>
                        </tr>
                        <tr>
                            <td><img src="assets/MNNIT_Academic_building_new.jpg" height="100" width="100">
                              <p>Prof. Parthasarathi<br>Chakrabarti,
                                 Director,<br> Motilal NIT-Allahabad</p>
                            </td>
                            <td><img src="assets/Administrative_Block_of_NIT_Durgapur.jpg" height="100" width="100">
                              <p>Dr.Tarkeshwar Kumar,Director,<br>NIT-Durgapur</p>
                            </td>
                            <td><img src="assets/MANIT.jpg" height="100" width="100">
                              <p>Dr.Appu Kuttan K.K.,Director,<br>NIT-Bhopal</p>
                            </td>
                            <td><img src="assets/SVNIT.jpg"width="100">
                              <p>Prof. Rajnish Shrivastava, Director,<br> NIT-Hamirpur</p>
                            </td>
                            <td><img src="assets/Administrative_Building,_MNIT_Jaipur.jpg" width="100">
                              <p>Prof. Inder Krishen Bhat, Director,<br>NIT- Jaipur</p>
                            </td>
                            <td><img src="assets/Main_Building,_NIT_Jalandhar.jpg" width="100">
                              <p>Dr. Samir Kumar Das, Director,<br>NIT-Jalandhar</p>
                            </td>
                            <td><img src="assets/NITW_Admin_Block.jpg"height="100" width="100">
                              <p>Prof. T. Srinivasa Rao, Director,<br>NIT-Warangal</p>
                            </td>
                            <td><img src="assets/NITK_mangalore.jpg" height="100" width="100">
                              <p>Dr. Swapan Bhattacharya, Director,<br>NIT-Surathkal</p>
                            </td>      
                        </tr>
                        
                        <tr>
                            <td><img src="assets/SVNIT.jpg" height="100" width="100">
                              <p>Prof. Prakash Devidas Porey, Director,<br>NIT - Surat</p>
                            </td>
                            <td><img src="assets/NIT_Srinagar.jpg" height="100" width="100">
                              <p>Prof. Rajat Gupta, Director,<br>NIT - Srinagar</p>
                            </td>
                            <td><img src="assets/National_institute_of_technology,_Silchar.jpg" height="100" width="100">
                              <p>Dr. N.V. Deshpande, Director,<br>NIT - Silchar</p>
                            </td>
                            <td><img src="assets/Acad-block-panorama.jpg" height="100" width="100">
                              <p>Prof. Sunil Kumar Sarangi, Director,<br>NIT- Rourkela</p>
                            </td>
                            
                            <td><img src="assets/Nitrr.jpg" height="100" width="100">
                              <p>Dr. Sudarshan Tiwari, Director,<br>NIT Raipur</p>
                            </td>
                            <td><img src="assets/Nit_Nagpur.jpg" height="100" width="100">
                              <p>Prof. Narendra S. Chaudhari, Director,<br>NIT – Nagpur</p>
                            </td>
                            <td><img src="assets/NIT_Kurukshetra_RR.png" height="100" width="100">
                              <p>Prof. Anand Mohan, Director,<br>NIT - Kurukshetra</p>
                            </td>
                            <td><img src="assets/NIT_Jamshedpur_main_building.jpg" height="100" width="100">
                              <p>Prof. Rambabu Kodali, Director,<br>NIT - Jamshedpur</p>
                            </td>      
                        </tr>
                        <tr>
                            <td><img src="assets/nit.png" height="200" width="200" allign="center">
                              <p>Dr.Sivaji Chakravorti , Director,<br>NIT - Calicut</p>
                            </td>
                        </tr>
                    </table> 
                </div>
                </div>      
              </div>
      </section>        
      
      <!-- -->
      
	    <section class="page7" id="FAQ" style="background-color:black;color:white;font-size:10px;">
	      <div class="page container">
            <br/>
              <br/>
              <br/>
              <br/>
              <h3 class="h1" align="center" style="background:#483D8B; color:orange">FAQ</h3> 
                <h5 align="left"><b>1. How to reach NIT -CALICUT ?</b></h5>
                <p align="justify" style="padding-left:10px;">
                    <font size="2">NITC  is well connected by railway,air and road facilities.All major station in india have trains to calicut railway station.
                    The Calicut international airport provides daily flights to and from major citites in india.
                    Route Details:
                    From Airport port   : Take a cab to reach NIT-Calicut.
                    From Railway Station: Take a cab or bus to reach NIT-Calicut. </font>
                </p>
              
               <h5 align="left"><b>2. Where will we stay ?</b></h5>
                <p align="justify" style="padding-left:10px;">
                    <font size="2"> Arrangements will made for the free accommodations and foos for the students from participating NITs,IITs, and other institutes
                    at the NIT-Calicut hostels.Sufficient assistance will be provided for the faclty members for their stay in hostels near NITC campus</p>
               </font>
               <h5 align="left"><b>3. What is expected from the programme ?</b></h5>
                <p align="justify" style="padding-left:10px;">
                     <font size="2">A wide exposure to students from different NITs, IITs and other institutes all over india.More internship opportunities to students
                         faculty. And also provides exchange of new innovative ideas</font></b></p> 
              
               <h5 align="left"><b>4. What if we have discrepancies while choosing the visisting teams ?</h5>
                <p align="justify" style="padding-left:10px;"></b>
          <font size="2">Team selection the visiting institute decisions.For contact mayankkumar@gmail.com</font></p>  
                  <h5 align="left"><b><font size="2">5. Who all are eligible to register?</b></h5>
                <p align="justify" style="padding-left:10px;">
                     Students pursuing course in any of NITs,IITs and other governments affliated institutes accross india are eligible to register.
                    Moreover reseach scholars are also allowed to participant.</b> </p> 
  	    </div>
      </section>
      <br/>
      <section class="page7" id="commity" style="background-color:black;color:white">
	      	<div class="page container"><br/><br/>
      		  <center><br/><h2 class="h1" style="font-size:60px; color:#967F08">Committee</h2></center>
              <p style="font-size:40px"><b>Patron</b></p>
              <p><b><a href="#">Dr. Shivaji Chakravorti&nbsp;&nbsp;</b></a>Director,NITC</p>
              <p style="font-size:40px"><b>Advisort Committee</b></p>
      		   <p style="color:#D828C6"><b>Dr. A.P Shashikala,Dean Academic</b></p> 
             	<p style="color:#D828C6"><b>Dr. Abrahan T. Mathew Dean,Research and Consultancy</b></p>
             	<p style="color:#D828C6"><b>Dr. G UnniKrishnan,Dean,Student Welfare</b></p>
             	<p style="color:#D828C6"><b>Dr. R Sridharan,Dean,Faculty Welfare</b></p>
                <h3 class="h1" style="font-size:35px; color:#967F08">Organizing Committee</h3>
                <p style="font-size:30px"><b>Convenor</b></p>
                <p style="font-size:20px"><b><a href="#">Dr. S.D Madhu Kumar</b></a></p>
                <p style="font-size:25px"><b>Associate Professor,CSE Department</b></p>
           	</div>
      </section>     
      <section class="page5" id="spo">
	     <div class="page container">
			<div class="row">
				
					
					
					
				<div class="col col-sm-12">
					<br/>
					
					<div class="container images" style="padding-right:50px;padding-top:60px;">
						<h2 align="center"><b>Sponsors ... !!</b></h2> 
						<div class="col col-sm-3 " style="padding-bottom:20px;">
							<img src="assets/Samsung.png" class="img img-responsive img-thumbnail ">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/images.png" class="img img-responsive img-thumbnail" >
						
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/del.png" class="img img-responsive img-thumbnail">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/AQ.png" class="img img-responsive img-thumbnail">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/tcs.png" class="img img-responsive img-thumbnail">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/direct.jpg" class="img img-responsive img-thumbnail">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/netcracker.jpg" class="img img-responsive img-thumbnail">
						</div>
						<div class="col col-sm-3" style="padding-bottom:20px;">
							<img src="assets/intel_spo.png" class="img img-responsive img-thumbnail">
						</div>
					</div>
				</div>
			</div>
  	     </div> 	     
      </section>
          
          
      <section id="cfl" style="background-color:#f1f2ea">
	      	<div class="page container">
				<h1 style="color:#4c0d12"><b>Call For Paper</b></h1>
				<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 0px 500px;
    
    text-decoration: inline;
    display: inline;
    font-size: 12px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button5 {
    background-color: #555555;
    color: black;
    border: 2px solid #555555;
}

.button5:hover {
    background-color: #600415;
    color: white;
}
</style>
<a class="btn  btn-primary btn-lg" style="width:100%;" href="../call_for_paper.php?id=1 ">Real-time Stream and processing techniques and Algorithms</a><br/><br/>
<a class="btn  btn-primary btn-lg" style="width:100%" href="../call_for_paper.php?id=2">Batch processing engine and techniques</a><br/></br>
<a class="btn  btn-primary " style="width:100%" href="../call_for_paper.php?id=3" >Network Design and Architecture</a></br/><br/>
<a class="btn  btn-primary" style="width:100%" href="../call_for_paper.php?id=4">Software Architecture and Middleware</a><br/><br/>
<a class="btn  btn-primary" style="width:100%" href="../call_for_paper.php?id=5">Network and Communication Protocols</a><br/><br/>
				<!--div class="btncont">
						  <a class="btn btn-lg btn-danger" href="../callforpaper.php" id="register">Paper Submission</a>
				</div-->
			</div>
	  </section>
          
      <section id="about_us" style="background-color:black">
			  <h1>About Us</h1>
				<h2>Conference Management Portal 2017, the first of its kind, is a conference aimed at bringing in student-teacher fraternity of CSE Departments of reputed IITSs,NITs etc across the nation under a single umbrella for exchange of ideas to spark innovation. The conference would serve as a platform to improve interaction and bridge the gap between faculty and students of different NITs. This would help identify patrons of similar research areas and help initiate collaboration in research projects to subsequently publish research papers. This conference presents an excellent opportunity for students among various NITs to collaborate and form strong ties of technical expertise. This year's edition of Conference Portal 2017 will be hosted by National Institute of Technology Calicut.</b></h2>
		</div>
      </section>
            
    </div>
  </div>
  
 <script src="js/validate.js"></script>
</body>
</html>
