<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>FullPage.js Template</title>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/alvarotrigo/fullPage.js/master/jquery.fullPage.css'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'>

      <link rel="stylesheet" href="css/style.css">
<script>/*
$(document).ready(function(){
  
  $("a").on('click', function(event) {

    
    if (this.hash !== "") {
   
      event.preventDefault();

   
      var hash = this.hash;

  
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
      
        window.location.hash = hash;
      });
    } 
  });
});*/
</script>
  
</head>

<body>
  <ul id="menu">
	<li data-menuanchor="firstPage" class="active"><a href="#section0">HOME</a></li>
	<li data-menuanchor="2nd"><a href="#second">About</a></li>
	<li data-menuanchor="3rd"><a href="index.php?user#thired">User Registration</a></li>
	<li data-menuanchor="4th"><a href="#four">Accomodation</a></li>
	<li data-menuanchor="5th"><a href="#five">Committee</a></li>
	<li data-menuanchor="6th"><a href="#six">Events</a></li>
	<li data-menuanchor="7th"><a href="#seven">FAQ</a></li>
    <li data-menuanchor="8th"><a href="#eight">Organizers</a></li>
	<li data-menuanchor="8th"><a href="#nine">Sponsors</a></li>
	
</ul>

<div id="fullpage">
	<div class="section active" id="section0">
	</div>
	<div  class="section" id="second">
            <br/>
             <br/>
                            
              <b><h1 class="h1" align="center">About Conference  Management Portal  </h1></b>
                            
              <p ><b>Conference Management Portal 2017, the first of its kind, is a conference aimed at bringing in student-teacher fraternity of CSE Departments of reputed IITSs,NITs etc across the nation under a single umbrella for exchange of ideas to spark innovation. The conference would serve as a platform to improve interaction and bridge the gap between faculty and students of different NITs. This would help identify patrons of similar research areas and help initiate collaboration in research projects to subsequently publish research papers. This conference presents an excellent opportunity for students among various NITs to collaborate and form strong ties of technical expertise. This year's edition of Conference Portal 2017 will be hosted by National Institute of Technology Calicut.</b></p>
					
					
	</div>
	
	<div class="section" id="thired">
		<div >
			 <div class="row">
             <div class="col col-sm-6">
             
             
             <?php
			 if(isset($_GET['user'])){
				 
				 echo  '<div class="container" style="padding-left:30%;padding-right:30%;">
					  <h2 align="center"><b>User Registration </b></h2>
					  <form class="form-horizontal">
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="name">Participant Name</label>
						  <div class="col-sm-10">
							<input type="text" class="form-control" id="name" placeholder="Enter name ">
						  </div>
						</div>
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Institute</label>
						  <div class="col-sm-10">
							<select name="institute">
								<option></option>
												
							
							</select>

							
							
						   </div>
						</div>
					
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Email:</label>
						  <div class="col-sm-10">
							<input type="email" class="form-control" id="email" placeholder="Enter email">
						  </div>
						</div>
						
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Phone</label>
						  <div class="col-sm-10">
							<input type="text" class="form-control" id="Phone" placeholder="Phone">
						  </div>
						</div>
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Programme</label>
						  <div class="col-sm-10">
							<select name="programe"  class="pull-left">
								<option>MCA</option>
								<option>Phd</option>
								<option>MTECH</option>				
								<option>Btech</option>
							</select>
						  </div>
						</div>
						
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Current Semester</label>
						  <div class="col-sm-10">
							<input type="text" class="form-control" id="csem" placeholder="Current Semester ">
						  </div>
						</div>
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="af">Accompanyning Faculty</label>
						  <div class="col-sm-10">
							<input type="text" class="form-control" id="af" placeholder="Accompanyning Faculty">
						  </div>
						</div>
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Gender</label>
						  <div class="col-sm-10 pull-left">
							<select name="Gender" class="pull-left">
								<option>Male </option>
								<option>Female</option>
							
							</select>

						  </div>
						</div>
						
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Food Preference </label>
						  <div class="col-sm-10">
							<input type="text" class="form-control" id="efp" placeholder="Food Preference ">
						  </div>
						</div>
						
						
						<div class="form-group">
						  <div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default">Submit</button>
						  </div>
						</div>
					  </form>
					</div>';		 
			 }
			 ?>
             
             
             </div>
             <div class="col col-sm-6"></div>
             
             </div>
		</div>
	</div>
    
	<div class="section" id="four">
		<div class="slide active">
			<div class="intro">
				<H1>portfolio</h1>
				 <!--Page content goes here-->
			</div>
		</div>
		<div class="slide">
			<div class="intro">
				 <!--Page content goes here-->
			</div>
		</div>
		<div class="slide">
			<div class="intro">
			 <!--Page content goes here-->
			</div>
		</div>
		<div class="slide">
			<div class="intro">
			 <!--Page content goes here-->
			</div>
		</div>
	</div>
    
	
    
	<div class="section" id="five">
		<div class="intro">
		 <!--Page content goes here-->
		</div>
		 <!--Page content goes here-->
	</div>
    
    <div class="section" id="six">
		<div class="intro">
		 <!--Page content goes here-->
		</div>
		 <!--Page content goes here-->
	</div>
    
    
    <div class="section" id="seven">
		<div class="intro">
		 <!--Page content goes here-->
		</div>
		 <!--Page content goes here-->
	</div>
        
    <div class="section" id="eight">
		<div class="intro">
		 <!--Page content goes here-->
		</div>
		 <!--Page content goes here-->
	</div>
	
	

	
	</div>
	
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdn.rawgit.com/alvarotrigo/fullPage.js/master/jquery.fullPage.min.js'></script>

      <script src="js/index.js"></script>

</body>
</html>
