function check_va(){
	   
	  var a =document.getElementById('name').value;
	  var b =document.getElementById('email').value;
	  var c =document.getElementById('Phone').value;  
	  var d =document.getElementById('af').value;
	    
	  if(/[a-zA-Z ]{5,20}/.test(a))
	  {
			
			if(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/.test(b))
			{
				
				if(/[0-9]{10}/.test(c))
				{
					
					if(/[a-zA-Z]{5,25}/.test(d))
					{
						
						return true;
						
					}else{
						
							alert("Invalid Faculty Name ");
							document.getElementById('af').style.border = "2px solid red";
							 return false;				
					}	
				}else{
						
					alert("Invalid Phone Number ");
					document.getElementById('Phone').style.border = "2px solid red";
					return false;
					
				}
			}else{
				
					alert("Invalid Email Address ");
					document.getElementById('email').style.border = "2px solid red";
					return false;
				
			}
	  }else{
		  document.getElementById('name').style.border = "2px solid red";
		  alert("Invalid User name ");
		  return false;
				
	  } 
}