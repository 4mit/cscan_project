<html>
<head>
<script src="root/bt/js/bootstrap.js"></script>
<link href="root/bt/css/bootstrap.css" rel="stylesheet" >

</head>
<body >
    <div class="container">
		<div class="row"> 
			<h1 align="center">Student Registration </h1>
            <form action="student.php" method="post" class="form-inline">
               <table width="200" border="1" class="table">
               <tbody>
					<tr>
                      <td>Name</td>
                      <td><input type="text" name="name" placeholder="Enter The Name" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>Institute Name</td>
                      <td><select name="institute" class="form-control"><br/><br/>
								<option value="null">Select College</option>
								<option>National Institute Of Techonology Warangal</option>
                                <option>National Institute Of Techonology Calicut</option>
                                    <option>National Institute Of Techonology Trichy</option>
                                    <option>National Institute Of Techonology Surathklal</option>
                                    <option>National Institute Of Techonology Krukshetra</option>
                                    <option>National Institute Of Techonology Bhopal</option>
                                    <option>National Institute Of Techonology Jameshedpur</option>
                                    <option>National Institute Of Techonology Rourkela</option>
                                    <option>National Institute Of Techonology Goa</option>
                                    <option>National Institute Of Techonology Hamirpur</option>
                                    <option>National Institute Of Techonology Jaipur</option>
                                    <option>National Institute Of Techonology Mizrom</option>
                                    <option>National Institute Of Techonology Patna</option>
                                    <option>National Institute Of Techonology Warangal</option>
                                    <option>National Institute Of Techonology Nagaland</option><br/>
                                    <option  id="others_institute" value="oth">Other</option><br/>
                           </select>
                                         &nbsp;&nbsp;Others:&nbsp;&nbsp;<input type="text" name="other_ins" id="others_institute" class="form-control">
                                    </td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td><input id ="email" type="email" name="email" placeholder="Enter Email Id" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>Phone</td>
                      <td><input type="text" name="phone" placeholder="Enter Contact Number" pattern="[0-9]{10}" required class="form-control"></td>
                    </tr>
                      <tr>
                      <td>PROGRAM</td>
                      <td><select name="program" class="form-control">
									<option value="null">Select Program</option>
                                    <option>MCA</option>
                                    <option>Phd</option>
                                    <option>MTECH</option>				
                                    <option>Btech</option>
                                    <option id="others_program" value="other1">Others</option><br/>
                                    </select>
                                    
                                       &nbsp;&nbsp;Others:&nbsp;&nbsp;<input type="text" name="other_prog"id="others_program" class="form-control">
                                    </td>
                    </tr>
                    <tr>
                      <td>Semester</td>
                      <td><input type="text" name="sem" placeholder="Enter Semester" required class="form-control"></td>
                    </tr>
                     <tr>
                      <td>Accompanying Faculty</td>
                      <td><input type="text" name="acc_faculty" placeholder="Enter The Faculty Name" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td>FOOD PREFERENCES</td>
                      <td><select name="food_pref" required class="form-control"><br/>
											<option value="null">Select Food</option>
                                            <option>Vegetarian</option>
                                            <option>Non-Vegetarian</option>
                                            </select></td>
                    </tr>
                  
                    <tr>
                      <td>&nbsp;</td>
                      <td><!--button type="submit" name="submit" onclick="return check_val();" class="btn btn-danger">Submit</button--->
                      <input type="submit" name="stu" value="Submit">
                      </td>
                    </tr>
                    
                  </tbody>
                </table>
                
                        
        <a href="root/demo.php">Back to home page </a>
        
        
        
       
     </div>
    </div> 
	<script>
	function check_val()
	{
		var a =document.getElementById('contact').value;            
		if(/[0-9]{10}/.test(a))
		  retrun true;
		else
		{	                     
                    alert("Invalid Phone Number ");
                    document.getElementById('contact').style.border = "2px solid red";
                    return false;                    
		}
	}
</script>	
	</body>
	</html>
				
				
<?php

$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca");
if(isset($_POST['stu']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$sem=$_POST['sem'];
$program=$_POST['program'];
$institute=$_POST['institute'];
$acc_faculty=$_POST['acc_faculty'];
$food=$_POST['food_pref'];

	if($institute == "null")
	{	
			echo "<script>alert('Please select institute')</script>";
			exit(0);
	}
	if($program == "null")
	{
		echo "<script>alert('Please select Program')</script>";
		exit(0);
	}
	if($food == "null")
	{
		echo "<script>alert('Please select Food Prefrence')</script>";
		exit(0);
	}
	if($institute=="oth" and $_POST['other_ins']=='')
	{
		echo "<script>alert('Please Type Institute name')</script>";
		exit(0);
	}
	
	
	if($program=="other1" and $_POST['other_prog']=='')
	{
		echo "<script>alert('Please Type Program')</script>";
		exit(0);
	}
	if($institute=="oth" and $_POST['other_ins']!='')
{
$institute=$_POST['other_ins'];}
if($program=="other1" and $_POST['other_prog']!='')
{
$program=$_POST['other_prog'];}
			
			
	
	$que="insert into student values('','$name','$email','$phone','$sem','$program','$institute','$acc_faculty','$food')";
	
   $run = mysqli_query($con,$que);
  
   if($run)
    {
	echo "<script>alert('DATA INSERTED SUCCESSFULL')</script>";
    }
}
?>
