<html>
<head>
	<script src="root/bt/js/bootstrap.js"></script>
<link href="root/bt/css/bootstrap.css" rel="stylesheet" >

</head>
	<body>
<style>
body
{
 background-color:#f9f6f4;
}
</style>
	
    <div class="container">
    <div class="row"> 
  			<h1 align="center" style="color:black">Paper Submission </h1><br/>
                        <form action="submission.php" method="post" class="form-inline">
                        
                        <table width="200" border="1" class="table">
                  <tbody>
                    <tr>
                      <td style="color:black"><b><i>Name</i></b></td>
                      <td><input type="text" name="name" placeholder="Enter The Name" required class="form-control"></td>
                    </tr>
                    
                    <tr>
                      <td style="color:black"><b><i>Sex</i></b></td>
                      <td><input type="radio" name="gender" value="Male" pattern="Male" class="form-control" ><font color="black">Male</font>
             <input type="radio" name="gender" value="Female" pattern="Female" id="check_gender" class="form-control" style="color:black"><font color="black">Female</font>
                      </td>
                    </tr>
                    <tr>
                      <td style="collor:black"><b><i>Designation</i></b></td>
                      <td><select name="des" placeholder="Enter The Designation" required class="form-control">
                                    <option>Professor</option>
                                    <option>Assitant Professor</option>
                                    <option>Associate Professor</option>
                                    <option value="other">Others</option><br/><br/>
                            </select>
                            
                            Others:&nbsp;&nbsp;<input type="text" id="desig" name="other_desig" class="form-control">
                            </td>
                    </tr>
                    <tr>
                      <td style="color:black"><b><i>Contact</i></b></td>
                      <td><input id ="contact" type="text" name="phone" placeholder="Enter The Mobile Number" pattern="[0-9]{10}" required class="form-control"></td>
                    </tr>
                    <tr>
                      <td style="color:black"><i><b>Email</b></i></td>
                      <td><input type="email" name="email" placeholder="Enter The Email" required class="form-control"></td>
                    </tr>
                    
                      <td style="color:black"><b><i>Submit  Paper</i></b></td>
                      <td><form action="test.html"enctype="multipart/form-data" method="post"><input type="text" name="textline" size="30" placeholder="Paper Title">
							<br/>
		<input type="file" name="datafile" size="40">
		</form>

                                    </td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td style="padding-left:100px "><button type="submit" name="submit" onclick="return check_val();" class="btn btn-danger">Submit</button></td>
                    </tr>
                    
                  </tbody>
                </table>
                
                        
        <a href="root/demo.php" style="color:BLACK">Back</a>
        
        
        
       
     </div>
    </div> 
	<script>
	function check_val()
	{
		var a =document.getElementById('contact').value;            
		if(/[0-9]{10}/.test(a))
		  retrun true;
		else
		{	                     
                    alert("Invalid Phone Number ");
                    document.getElementById('contact').style.border = "2px solid red";
                    return false;                    
		}
	}
</script>	

<head>
	</html>


<?php 
	
if(isset($_POST['submit']))
{

$name=$_POST['name'];
$sex=$_POST['gender'];
$des=$_POST['des'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$datafile=$_POST['textline'];
$con=new mysqli("localhost","m140366ca","m140366ca","db_m140366ca");
echo $des;
if($des=='other' && $_POST['other_desig']=='')
{
  echo '<script>alert("Choose appropriate designation")</script>';
  exit(0);
}
if($des=='other' && $_POST['other_desig']!='')
{
	$des=$_POST['other_desig'];
}

if($con)
{
  	
  
  if($sex =="Male" || $sex=="Female")
  {
   $sql="insert into submission values('$name','$sex','$des','$phone','$email','$datafile')";

	if($con->query($sql))
        echo '<script>alert("DATA INSERTED SUCCESSFULL")</script>';
	else
	echo '<script>alert(" NOT INSERTED SUCCESSFULL")</script>';
  }
  else
  {
        echo "<script>alert('Select Gender')</script>";
  }			
}
else
{
 echo "cant connect";
}
}
?>
