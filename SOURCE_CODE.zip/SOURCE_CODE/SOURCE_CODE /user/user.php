
<html>
    
<head>
    <script src="../root/bt/js/bootstrap.js"></script>
<link href="../root/bt/css/bootstrap.css" rel="stylesheet" >
    <script src="../root/jquery-1.9.1.js"></script>
 <style>
    body{padding-top:30px;}

.glyphicon {  margin-bottom: 10px;margin-right: 10px;}

small {
display: block;
line-height: 1.428571429;
color: #999;
}
    
    </style> 
    
    </head>
    <body>
    
    
    <?php
session_start();
$con=new mysqli("localhost","root","nsl","nts");	
if(isset($_SESSION['user']))
{
    
        $user = $_SESSION['user'];
    
        $ds= "select * from student where email='$user'";

            $result = $con->query($ds);
            echo '<table class="well table" align="center">';
            while($re  = $result->fetch_assoc())
            {
                echo '<tr><td>Name</td><td>' . $re['stu_name'] . '</td></tr>';
                                    
                echo '<tr><td>Email </td><td>' . $re['email'] . '</td></tr>';
                                    
                echo '<tr><td>Phone number</td><td> '. $re['phone'] . '</td></tr>';
                                    
                echo '<tr><td>Current Semester </td><td>' .  $re['sem']  . '</td></tr>';
                                    
                echo '<tr><td>Progran </td><td>' . $re['program'] . '</td></tr>';
                                    
                echo '<tr><td>Institutre </td><td>' . $re['institute'] . '</td></tr>';
                                    
                echo '<tr><td>Accomplayiong Faculty </td><td>' . $re['acm_faculty'] . '</td></tr>';
                                    
                echo '<tr><td>Food preferebce I\'v Given </td><td>' . $re['food_pref'] . '</td></tr>';
                                    
            }
     
            
    
}


if(isset($_POST['change_pass']))
{
    
    $s  =$_POST['new_pass'];
    
   // $update = "update student set pass = '$s' where stu_id =''";
    
}

?>
   <div class="well">
        <form action="user.php" method="POST"> 
        <input type="text" name="new_pass" placeholder="Enter New password">
        <button type="submit" name="change_password">Change Password </buttton>
        
    </form>
       
    </div>     
    <br/>
    <a href="../logout.php">Logout </a>    
    </div>
    </body>
 
</html>